    @php
$getSetting = Helper::getSetting();
$account = Helper::getQRCode($getSetting->account_id);
//dd($data[0]['Admission']);

@endphp

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fees Print </title>
    <style>
     
        body {
            font-family: Arial, sans-serif;
            font-size:10px;
            max-width:750px;
            margin: 25px auto;
            //border: 0.5px solid; 
        }
        
        .student_img {
            width: 80px; 
            height:100; 
            margin-top: 5%;
            margin-left:20%;
            padding-bottom: 10px;
        }
        
        .row{
            margin-right: 0px;
        }
        .img_background_fixed{
            position: relative;
        }
        
        .img_absolute{
            position: absolute;
            top: 85px;
            width: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100%;
            right: 0;
        }
        
        .backhround_img{
           opacity: 0.3;
           width: 34%;
        }

        table{
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            border: 1px solid #1a1919;
            text-align: left;
            padding: 5px;
        }
        th {
            background-color: #f2f2f2;
        }
        .invoice-header {
            margin-bottom: 20px;
            text-align:'center'
        }

        .border_none{
            border: none;
        }
        
        .bg_color_heading td{
            background-color:#f2f2f2;
            font-weight:600;
        }
        
        .information_text{
            font-size:12px;
        }
        
        .note_listing{
            margin-bottom:0px;
            /*list-style:none;*/
        }
        
        .note_listing li{
            margin-top:10px;
            font-size:12px;
        }
        .copy_font{
            text-align: center;
            margin: 0px;
            font-size: 17px;
            font-family: emoji;
        }
        
        @media print {
        .pageBreak {
            page-break-after: always;
        }
    
        @page {size: portrait}
        @page {
        size: 8.5in 11in;
        margin: 0;
    }
}
    .canceled{
        font-size: 80px;
        color: #ff00008a;
        position: absolute;
        top: 103px;
        width: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
        right: 0;
        transform: rotate(-26deg);
    }
     
   </style>
</head>
<body class='page'>
<div>
@if(!empty($data->status) && $data->status == 2)
    <p class="canceled">Canceled</p>
@endif

<table style="border-bottom: 0px solid;width:100%;margin-bottom: 0px;background-color: #e7dd64;">
			<tbody >
	<tr >

      <td   style="border:none" rowspan="4" rowspan="2">
          <img  rowspan="4" src="{{ env('IMAGE_SHOW_PATH').'/setting/left_logo/'.$getSetting['left_logo'] }} " style="width: 120px;height: 60px;" onerror="this.src='{{ env('IMAGE_SHOW_PATH').'/default/rukmani_logo.png' }}'"></td>
          
          </td>
        <td class="border_none" width='50%' style="font-size:30px;text-align:center;"> <span class="style71"><strong>{{$getSetting['name'] ?? ''}}</strong></span></td>
        <td class="border_none" width='25%'> 
        </td>
   
  
   </tr>
   <tr>
<td class="border_none" style="text-align: center;font-size: 16px;" ><b>Fees Receipt</b></td>
<td class="border_none" width='25%'> 
        </td>
<!--<td class="border_none" style="text-align: right;font-size: 16px;"><b>Office Copy </b></td>-->
</tr>
  </tbody>
  </table> 

  
 
<table style="margin-bottom: 0px;">
     @php
                             $sessions  = DB::table('sessions')->whereNull('deleted_at')->where('id',$invoice_data->session_id ?? '')->first();
     @endphp
      	<tbody >
      	    
      	    <tr><td rowspan='3'style="text-align: center;"><b>Receipt No.: <span style='color:red' >{{$invoice_data->receipt_no ?? ''}}</span></b>
      	  
      	    </td>
      	    </tr>
      <tr>
          <th>Name</th>
          <td>{{ $invoice_data->first_name ?? '' }} {{$invoice_data->last_name ?? '' }}</td>
          <th>Father's Name</th>
          <td>{{ $invoice_data->father_name ?? '' }}</td>
         
      </tr>
      <tr>
          <th>Class</th>
          <td>
              {{ $invoice_data->class_name ?? '' }}
         </td>
          <th></th>
          <td></td>
         
      </tr>
      <tr>
          <td rowspan='2'style="text-align: center;">
      	    <b>Session : <span>{{$sessions->from_year ?? ''}}-{{$sessions->to_year ?? ''}}</span></b>
      	    </td>
          <th>Payment Date</th>
          <td>{{ date('d-M-Y', strtotime($invoice_data->payment_date ?? '')) }}</td>
          <th>Generated On</th>
          <td>{{ date('d-M-Y / h:m A', strtotime($invoice_data->created_at ?? '')) }}</td>
          
      </tr>
      <tr>
          <th>Remark</th>
          <td colspan="3">{{$invoice_data->remark ?? ''}}</td>
      </tr>
       </tbody>
      
  </table>
<table style="margin-bottom:0px;">
        <thead>
            <tr>
                <th  width='30%'>Head Name</th>
                <th>Due Date</th>
                <th>Amount</th>
                <th>Late Fee</th>
                <th>Paid</th>
              
            </tr>
        </thead>
        <tbody>
            
            @if(!empty($data))
            @php
            $total_amount = 0;
            @endphp
            @foreach($data as $item)
            <tr>
                <td >
                    @php
                        $feesGroup  = DB::table('fees_group')->whereNull('deleted_at')->where('id',$item['fees_group_id'])->first();
                        $fees_master  = DB::table('fees_master')->whereNull('deleted_at')->where('fees_group_id',$item['fees_group_id'])->where('class_type_id',$invoice_data->class_type_id ?? '')->first();
                        
                    @endphp
                
                {{$feesGroup->name ?? ''}}
                </td>
                <td>{{date('d-M-Y', strtotime($fees_master->installment_due_date ?? '')) ?? '' }}</td>
                <td>{{ number_format($fees_master->amount ?? 0, 2) }}</td>
                <td> {{ number_format($item['installment_fine'] ?? 0, 2) }}
                @php
                $total_amount += $item['total_amount'] ?? 0;
                @endphp
                
                </td>
                <td>{{ number_format($item['total_amount'] ?? 0, 2) }}</td>
                
            </tr>
            @endforeach
            @endif
            <!-- Add more rows for additional items -->
        </tbody>

  </table>
        @php
            $payment_name = DB::table('payment_modes')->whereNull('deleted_at')->where('id',$data[0]->payment_mode_id)->first();
        @endphp
           
      
  <table style="margin-bottom: 0px;">
        <tbody>
            
            <tr class="bg_color_heading">
                <td >Payment Mode</td>
            
                    <td > @if(!empty($data['cheque_number'] )) Cheque Number @else Transaction Id @endif</td>
                    <td >Bank Name</td>
                @if(!empty($data['cheque_date'] ?? ''))   <td >Cheque Date</td> @endif
                <td colspan="4" style="text-align: right;">Total Paid Amount</td>
            </tr>
            
            <tr>
                <td >{{ $payment_name->name ?? '' }}</td>
            
                    <td >{{ $data[0]->transition_id ?? $data['cheque_number'] ?? ''}}</td>
                    <td >{{ $data[0]->bank_name ?? $invoice_data->bank_name }}</td>
                 @if(!empty($data->cheque_date))   <td >{{ date('d-M-Y', strtotime($data->cheque_date ?? ''))  }}</td> @endif
              
                <td  colspan="4" id="inNumber" style="text-align: right;">INR {{ number_format ($total_amount ?? 0, 2)  }}</td>
            </tr>
            
            <tr>
                <th colspan="1" style="text-align: left;">Amount In Words :-</th>
                
                @php
                 $formatter = new NumberFormatter('en_IN', NumberFormatter::SPELLOUT);
                $words = $formatter->format($total_amount);
                $words .= ' rupees';
                @endphp
                <td colspan="5" style="text-align: right;"><b id="inWords" style='text-transform: capitalize;'>  {{ $words}}</b></td>
            </tr>
            
        </tbody>
    </table>
    <p style="margin: 3px;">Note :- </p>
    <p style="margin: 3px;">1. No admission fee will be charged for new admission in Nursery to Std.I</p>
    <p style="margin: 3px;">2. Admission fee of Rs.2500 will be applicable for new admission in Std.II to VIII.</p>
    <p style="margin: 3px;">3. Parents have the option to deosite fee in advance for the whole year.</p>
    <p style="margin: 3px;">4. Fees can also be deposited through account payee Cheque, RTGS/NEFT in the Bank A/c of the school.</p>
    <p style="margin: 3px;">5. **I quarter fee to be deposited alongwith student data updation form/admission form.</p>
    <p style="margin: 3px;">6. This is a computer generated copy and doesn’t require a signature.</p>
<br>
<hr>
</div>
  
</div>

<br>
<div> 


</body>
</html>